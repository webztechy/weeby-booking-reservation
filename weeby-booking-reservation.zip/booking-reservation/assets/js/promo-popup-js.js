/*
 * Project Name: Booking & Reservation
 * Author by: Renier C. Rumbaoa
 * Email: renierrumbaoa@gmail.com
 * Company: Era Information Technology
 *
 */

//alert('sdfds');
jQuery(function (){
	
});

